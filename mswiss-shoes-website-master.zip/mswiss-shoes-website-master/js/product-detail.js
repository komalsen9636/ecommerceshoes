$(document).ready(function(){
    $(".owl-carousel").owlCarousel({
        loop: false,
        items: 1,
        thumbs: true,
        thumbImage: true,
        thumbContainerClass: 'owl-thumbs',
        thumbItemClass: 'owl-thumb-item'
    });

});